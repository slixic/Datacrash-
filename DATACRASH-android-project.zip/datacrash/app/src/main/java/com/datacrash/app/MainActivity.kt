package com.datacrash.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.datacrash.app.data.AppDatabase
import com.datacrash.app.data.Note
import com.datacrash.app.reminders.ReminderScheduler
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Night = Color(0xFF050709)
private val Panel = Color(0xFF101619)
private val Panel2 = Color(0xFF171D20)
private val Red = Color(0xFFB63D4A)
private val RedDark = Color(0xFF55232B)
private val Yellow = Color(0xFFD8B65B)
private val Cyan = Color(0xFF55C9C4)
private val Muted = Color(0xFF849092)

class MainActivity : ComponentActivity() {
    private val requestNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val dao = AppDatabase.get(this).noteDao()
        setContent { DataCrashApp(dao, this) }
    }
}

@Composable
private fun DataCrashApp(dao: com.datacrash.app.data.NoteDao, activity: ComponentActivity) {
    val notes by dao.observeActive().collectAsState(initial = emptyList())
    val archived by dao.observeArchived().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var selectedContact by remember { mutableStateOf<String?>(null) }
    var showComposer by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var showArchive by remember { mutableStateOf(false) }
    var reminderAt by remember { mutableStateOf<Long?>(null) }
    var draft by remember { mutableStateOf("") }
    var draftContact by remember { mutableStateOf("MY NOTES") }
    val contacts = (notes.map { it.contact }.distinct() + listOf("MY NOTES", "IDEAS", "PROJECTS", "PERSONAL")).distinct()
    val visibleContacts = if (search.isBlank()) contacts else contacts.filter { c -> c.contains(search, true) || notes.any { it.contact == c && it.body.contains(search, true) } }

    MaterialTheme(colorScheme = darkColorScheme(primary = Yellow, secondary = Cyan, background = Night, surface = Panel)) {
        BoxWithConstraints(Modifier.fillMaxSize().background(Night)) {
            val landscape = maxWidth > maxHeight
            Column(Modifier.fillMaxSize()) {
                GameHeader()
                if (landscape) {
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        ContactPane(visibleContacts, selectedContact, search, { search = it }, { selectedContact = it }, Modifier.width(maxWidth * .39f).fillMaxHeight())
                        ConversationPane(selectedContact, notes.filter { it.contact == selectedContact }, onAdd = { draftContact = selectedContact ?: "MY NOTES"; draft = ""; reminderAt = null; showComposer = true }, onFavorite = { n -> scope.launch { dao.update(n.copy(isFavorite = !n.isFavorite)) } }, onArchive = { n -> scope.launch { dao.update(n.copy(isArchived = true)) } }, modifier = Modifier.weight(1f).fillMaxHeight())
                    }
                } else {
                    if (selectedContact == null) {
                        ContactPane(visibleContacts, null, search, { search = it }, { selectedContact = it }, Modifier.weight(1f).fillMaxWidth())
                    } else {
                        Column(Modifier.weight(1f)) {
                            Row(Modifier.fillMaxWidth().background(Panel).clickable { selectedContact = null }.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                androidx.compose.material3.Icon(Icons.Default.ArrowBack, null, tint = Red)
                                Spacer(Modifier.width(8.dp)); GameText(selectedContact!!.uppercase(), Yellow, 13, true)
                            }
                            ConversationPane(selectedContact, notes.filter { it.contact == selectedContact }, onAdd = { draftContact = selectedContact!!; draft = ""; reminderAt = null; showComposer = true }, onFavorite = { n -> scope.launch { dao.update(n.copy(isFavorite = !n.isFavorite)) } }, onArchive = { n -> scope.launch { dao.update(n.copy(isArchived = true)) } }, modifier = Modifier.weight(1f).fillMaxWidth())
                        }
                    }
                }
                BottomStatus()
            }
            if (showComposer) {
                AlertDialog(
                    onDismissRequest = { showComposer = false },
                    containerColor = Panel2,
                    title = { GameText("NEW MESSAGE / NOTE", Yellow, 14, true) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(value = draftContact, onValueChange = { draftContact = it }, label = { Text("CONTACT / CATEGORY") }, singleLine = true, colors = cyberFieldColors())
                            OutlinedTextField(value = draft, onValueChange = { draft = it }, label = { Text("MESSAGE TEXT") }, minLines = 4, colors = cyberFieldColors())
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = { pickDateTime(activity) { reminderAt = it } }) { androidx.compose.material3.Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(5.dp)); Text("SET REMINDER", color = Cyan) }
                                reminderAt?.let { Text(SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(it)), color = Yellow, fontSize = 11.sp) }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = {
                        if (draft.isNotBlank()) scope.launch {
                            val id = dao.insert(Note(contact = draftContact.ifBlank { "MY NOTES" }, body = draft.trim(), reminderAt = reminderAt))
                            reminderAt?.let { ReminderScheduler.schedule(activity, id, it, draftContact, draft.trim()) }
                            selectedContact = draftContact.ifBlank { "MY NOTES" }
                            showComposer = false
                        }
                    }) { Text("SAVE", color = Yellow) } },
                    dismissButton = { TextButton(onClick = { showComposer = false }) { Text("CANCEL", color = Muted) } }
                )
            }
        }
    }
}

@Composable
private fun GameHeader() {
    Column(Modifier.fillMaxWidth().background(Night)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            GameText("DATACRASH", Yellow, 15, true)
            GameText("LOCAL DATABASE   •   OFFLINE", Cyan, 9, true)
            GameText("V1.0", Red, 10, true)
        }
        Box(Modifier.fillMaxWidth().height(2.dp).background(Red))
        Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 10.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            GameText("JOURNAL", Cyan, 10, true); GameText("MESSAGES", Yellow, 10, true); GameText("CALENDAR", Muted, 10, true); GameText("ARCHIVE", Muted, 10, true)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(RedDark))
    }
}

@Composable
private fun ContactPane(contacts: List<String>, selected: String?, search: String, onSearch: (String) -> Unit, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.background(Night).padding(horizontal = 9.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { GameText("MESSAGES", Red, 11, true); Spacer(Modifier.weight(1f)); GameText("SORT / FILTER", Muted, 8) }
        Spacer(Modifier.height(7.dp))
        OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth().height(48.dp), placeholder = { Text("SEARCH DATABASE", fontSize = 10.sp, color = Muted) }, leadingIcon = { androidx.compose.material3.Icon(Icons.Default.Search, null, tint = Cyan) }, singleLine = true, colors = cyberFieldColors())
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            items(contacts) { contact ->
                Row(Modifier.fillMaxWidth().background(if (contact == selected) RedDark else Panel).border(width = 1.dp, color = if (contact == selected) Red else Color(0xFF20292B)).clickable { onSelect(contact) }.padding(horizontal = 8.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(5.dp).height(19.dp).background(Red)); Spacer(Modifier.width(8.dp))
                    GameText(contact.uppercase(), if (contact == selected) Yellow else Cyan, 10, true, Modifier.weight(1f), maxLines = 1)
                    GameText("⌄", Red, 13, true)
                }
            }
        }
    }
}

@Composable
private fun ConversationPane(contact: String?, notes: List<Note>, onAdd: () -> Unit, onFavorite: (Note) -> Unit, onArchive: (Note) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.background(Night).padding(horizontal = 10.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            GameText(contact?.uppercase() ?: "SELECT A CONTACT", Yellow, 11, true, Modifier.weight(1f))
            TextButton(onClick = onAdd, contentPadding = PaddingValues(horizontal = 8.dp)) { androidx.compose.material3.Icon(Icons.Default.Add, null, tint = Red); Text("NEW", color = Red, fontSize = 10.sp) }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(RedDark))
        if (contact == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { GameText("SELECT A CONTACT TO OPEN DATASTREAM", Muted, 10) }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(notes, key = { it.id }) { note ->
                    Column(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Column(Modifier.fillMaxWidth(.88f).border(1.dp, Yellow.copy(alpha = .7f)).background(Color(0xFF171612)).padding(10.dp)) {
                                GameText(note.body, Yellow, 11, false)
                                Spacer(Modifier.height(5.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    GameText(SimpleDateFormat("dd.MM.yyyy  HH:mm", Locale.getDefault()).format(Date(note.createdAt)), Muted, 8, false, Modifier.weight(1f))
                                    androidx.compose.material3.Icon(Icons.Default.Favorite, null, tint = if (note.isFavorite) Red else Muted, modifier = Modifier.size(14.dp).clickable { onFavorite(note) })
                                    Spacer(Modifier.width(8.dp))
                                    androidx.compose.material3.Icon(Icons.Default.Archive, null, tint = Muted, modifier = Modifier.size(14.dp).clickable { onArchive(note) })
                                }
                                note.reminderAt?.let { GameText("REMINDER • " + SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(it)), Cyan, 8, true) }
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                GameText("LOCAL DATASTREAM", Cyan, 8, true, Modifier.weight(1f))
                TextButton(onClick = onAdd) { GameText("+ SEND / SAVE", Red, 9, true) }
            }
        }
    }
}

@Composable
private fun BottomStatus() {
    Column {
        Box(Modifier.fillMaxWidth().height(1.dp).background(RedDark))
        Row(Modifier.fillMaxWidth().background(Night).padding(horizontal = 10.dp, vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            GameText("● SYSTEM READY", Cyan, 8, true); GameText("DATACRASH // LOCAL STORAGE", Muted, 8)
        }
    }
}

@Composable
private fun GameText(text: String, color: Color, size: Int, bold: Boolean = false, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE) {
    Text(text = text, modifier = modifier, color = color, fontSize = size.sp, fontFamily = FontFamily.Monospace, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, lineHeight = (size + 3).sp, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}

@Composable
private fun cyberFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Yellow, unfocusedTextColor = Cyan,
    focusedBorderColor = Red, unfocusedBorderColor = RedDark,
    focusedLabelColor = Yellow, unfocusedLabelColor = Muted,
    cursorColor = Cyan, focusedContainerColor = Panel, unfocusedContainerColor = Panel
)

private fun pickDateTime(activity: ComponentActivity, onPicked: (Long) -> Unit) {
    val now = Calendar.getInstance()
    DatePickerDialog(activity, { _, year, month, day ->
        val selected = Calendar.getInstance().apply { set(year, month, day, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), 0) }
        TimePickerDialog(activity, { _, hour, minute ->
            selected.set(Calendar.HOUR_OF_DAY, hour); selected.set(Calendar.MINUTE, minute)
            onPicked(selected.timeInMillis)
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
    }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
}
