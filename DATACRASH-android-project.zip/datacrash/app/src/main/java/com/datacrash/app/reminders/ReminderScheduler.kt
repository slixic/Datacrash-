package com.datacrash.app.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ReminderScheduler {
    fun schedule(context: Context, noteId: Long, atMillis: Long, contact: String, body: String) {
        if (atMillis <= System.currentTimeMillis()) return
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("title", "DATACRASH • $contact")
            putExtra("body", body)
            putExtra("notificationId", noteId.toInt())
        }
        val pending = PendingIntent.getBroadcast(context, noteId.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pending)
        else alarm.set(AlarmManager.RTC_WAKEUP, atMillis, pending)
    }
}
