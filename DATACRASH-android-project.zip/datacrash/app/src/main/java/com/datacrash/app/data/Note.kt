package com.datacrash.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contact: String,
    val body: String,
    val createdAt: Long = System.currentTimeMillis(),
    val reminderAt: Long? = null,
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false
)
