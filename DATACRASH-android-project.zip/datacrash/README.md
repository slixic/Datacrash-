# DATACRASH — Android project

An offline-first Android notebook prototype with a Cyberpunk 2077 Journal/Messages-inspired layout. The visual reference is the three screenshots supplied by the user in the conversation.

## Current prototype foundation
- Kotlin + Jetpack Compose UI.
- Responsive layout: portrait shows contacts then a full-width conversation; landscape shows a left contact column and right conversation column.
- Local Room database for notes.
- Contact/category names are user-editable when creating a note.
- Create and save notes in a conversation.
- Favorite and archive actions are wired to the local database (archive view is not yet implemented).
- Date/time reminder picker and Android notification scheduling for saved notes.
- No AI or network dependency.

## Still to implement before calling this DATACRASH 1.0
- A dedicated calendar/agenda screen and reminder management (edit, repeat, cancel).
- Archive and favorites screens, full-text search across note content, attachments/photos/files.
- Rescheduling reminders after device reboot and timezone changes.
- Refined pixel-level styling against the supplied screenshots, custom font/assets, app icon, sound/animation and accessibility polish.
- Build and test the APK on the target POCO X6 Pro 5G.

## Open in Android Studio
1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open this folder (`datacrash`) as an existing Gradle project.
3. Let Gradle sync and download dependencies.
4. Connect the POCO X6 Pro with USB debugging enabled, or create an Android emulator.
5. Run the `app` configuration. To make an APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Package name: `com.datacrash.app`  
App label: `DATACRASH`

## Build APK automatically with GitHub (no Android Studio needed)
1. Create a new empty repository on GitHub named `DATACRASH`.
2. Upload the contents of this project folder to the repository (the `.github` folder must be included).
3. Open the repository's **Actions** tab and select **Build DATACRASH APK**.
4. Press **Run workflow**. Wait for the run to finish successfully.
5. Open the completed run and download the `DATACRASH-debug-apk` artifact. Extract it to get `app-debug.apk`.
6. Transfer `app-debug.apk` to the phone and install it. Android may ask permission to install apps from that source.

The workflow builds a debug APK. It is suitable for personal testing; a release build and signing setup can be added later.
